package com.example.loginrestapi;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    //Datos Volley
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    private EditText cajaEmail;
    private EditText cajaPass;
    private Button btnIniciarSesion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        inicializarElementos();

        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    verificar(cajaEmail.getText().toString(), cajaPass.getText().toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });

    }

    private void verificar(String email, String password) throws JSONException {
        JSONObject postparams = new JSONObject();
        postparams.put("email", email);
        postparams.put("password", password);

        String url = "http://192.168.1.74/eFirmas/public/login";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postparams,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        startActivity(new Intent(MainActivity.this, SecondActivity.class));
                        //Toast.makeText(MainActivity.this, "RESPUESTA: " + response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "ERROR: " + error.toString(), Toast.LENGTH_LONG).show();
                        //System.out.println("EEEERRROR: " + error.toString());
                    }
                }
                ){
            @Override
            public  Map<String,String> getHeaders(){

                Map<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/json");

                return headers;
            }

        };
        requestQueue.add(jsonObjectRequest);
    }




    private void inicializarElementos() {
        cajaEmail = findViewById(R.id.editText_login_email);
        cajaPass = findViewById(R.id.editText_login_password);
        btnIniciarSesion = findViewById(R.id.button_login_login);
        requestQueue = Volley.newRequestQueue(MainActivity.this);

    }


}