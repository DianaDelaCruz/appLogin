package com.example.loginrestapi;


import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.android.*;


import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static java.lang.String.*;


public class MainActivity extends AppCompatActivity {
    //Datos Volley
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    private EditText cajaEmail;
    private EditText cajaPass;
    private Button btnIniciarSesion;
    String urlWs = "http://192.168.1.74/eFirmas/public/login";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        inicializarElementos();

        gettoken();

        verificarUsuario(cajaEmail.getText().toString(), cajaPass.getText().toString());


    }

    public void gettoken(){
        String uri= "http://192.168.1.74/eFirmas/public/login";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        URL url= null;
        HttpURLConnection conn;

        try {
            url = new URL(uri);
            conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type","application/json");
            conn.setRequestProperty("Accept", "application/json");

            conn.connect();

            if(conn.getResponseCode() == 200){
                System.out.println("Exito tenemos exito");
            }
            System.out.println(conn.getResponseMessage());


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    private void verificarUsuario(String email, String password) {

        String url = urlWs + "?email=" + email + "&password=" + password;

        stringRequest = new StringRequest(StringRequest.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                startActivity(new Intent(MainActivity.this, SecondActivity.class));

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Hubo un problema a la hora de iniciar sesión", Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(stringRequest);


    }

    private void inicializarElementos() {
        cajaEmail = findViewById(R.id.editText_login_email);
        cajaPass = findViewById(R.id.editText_login_password);
        btnIniciarSesion = findViewById(R.id.button_login_login);
        requestQueue = Volley.newRequestQueue(getApplicationContext());

    }

    /**
     * Open a new activity window.
     */
    private void goToSecondActivity() {
        Bundle bundle = new Bundle();
        bundle.putString("email", valueOf(cajaEmail));
        bundle.putString("password", valueOf(cajaPass));
        bundle.putString("baseUrl", urlWs);

        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }


}
